<?php
include 'assets/core/connection.php';
$mid = $_GET['mid'];

$attendance= select("SELECT * FROM membership_tb WHERE member_id='$mid' ");
foreach($attendance as $attendances){
       $img     = $attendances['member_image'];
       $mem_id   = $attendances['member_id'];
       $gp_name  = $attendances['group_name'];
       $fll_name = $attendances['full_name'];
       $gender   = $attendances['gender'];
       $p_num    = $attendances['phone_number'];
}
      
$minn = select("SELECT * FROM ministry_tb WHERE group_id='$gp_name' ");
    foreach($minn as $minnrow){
        @$minnamee = $minnrow['group_name'];
    }

  $flag1 =1;
  $m_attendance = insert("INSERT INTO mem_attendance(member_id,ministry_id,ministry_name,full_name,gender,phone,status,date_reg,flag1) VALUES('".$attendances['member_id']."','$gp_name','".@$minnamee."','".$fll_name."','".$gender."','".$p_num."','absent',CURDATE(),'$flag1');)");

    if($m_attendance){
        $s = "absentsuccess";
        echo "<script>window.location.href='attendance?aba=$s'</script>"; 
    }else{
        $s = "absentfailed";
        echo "<script>window.location.href='attendance?aba=$s'</script>";  
    }

?>