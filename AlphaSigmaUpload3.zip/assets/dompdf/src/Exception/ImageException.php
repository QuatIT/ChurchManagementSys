<?php

namespace Dompdf\Exception;

use Dompdf\Exception;


class ImageException extends Exception
{

    
    function __construct($Vw4u5rrepkk1 = null, $Vl0bhwxpf0qo = 0)
    {
        parent::__construct($Vw4u5rrepkk1, $Vl0bhwxpf0qo);
    }

}
