<?php


namespace Dompdf;


class Exception extends \Exception
{

    
    public function __construct($Vw4u5rrepkk1 = null, $Vl0bhwxpf0qo = 0)
    {
        parent::__construct($Vw4u5rrepkk1, $Vl0bhwxpf0qo);
    }
}
