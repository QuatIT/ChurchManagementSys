<?php


namespace Svg\Tag;

class RadialGradient extends AbstractTag
{
    public function start($Voywws15cvz5)
    {

    }
}
