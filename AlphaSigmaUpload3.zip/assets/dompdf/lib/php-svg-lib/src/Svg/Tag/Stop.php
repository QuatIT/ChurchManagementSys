<?php


namespace Svg\Tag;

class Stop extends AbstractTag
{
    public function start($Voywws15cvz5)
    {

    }
}
