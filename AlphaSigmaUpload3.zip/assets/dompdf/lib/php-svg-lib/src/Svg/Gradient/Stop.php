<?php


namespace Svg\Gradient;

class Stop
{
    public $Vq154qppcleo;
    public $Vexxkxtdr01j;
    public $Vdrvff4n2sqc = 1.0;
}
