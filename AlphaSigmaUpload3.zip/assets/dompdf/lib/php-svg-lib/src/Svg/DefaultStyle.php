<?php


namespace Svg;

class DefaultStyle extends Style
{
    public $Vexxkxtdr01j = '';
    public $Vdrvff4n2sqc = 1.0;
    public $Vsagginauquc = 'inline';

    public $Vm4rhtdms15t = 'black';
    public $Vm4rhtdms15tOpacity = 1.0;
    public $Vm4rhtdms15tRule = 'nonzero';

    public $Vihuafvzvxcv = 'none';
    public $VihuafvzvxcvOpacity = 1.0;
    public $VihuafvzvxcvLinecap = 'butt';
    public $VihuafvzvxcvLinejoin = 'miter';
    public $VihuafvzvxcvMiterlimit = 4;
    public $VihuafvzvxcvWidth = 1.0;
    public $VihuafvzvxcvDasharray = 0;
    public $VihuafvzvxcvDashoffset = 0;
}
