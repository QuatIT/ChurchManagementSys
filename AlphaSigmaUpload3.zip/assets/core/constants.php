<?php
 //error_reporting(0);
define("DB_SERVER" , "localhost");
//define("DB_USER" , "therohic_rikalpha");
//define("DB_USER" , "quatitso_church");
define("DB_USER" , "root");
//define("DB_PASSWORD" , "#edicon,123456789.");
//define("DB_PASSWORD" , "L%myZwGoIBRE");
define("DB_PASSWORD" , "");
//define("DB_PASSWORD" , "Church,12345.");
//define("DB_NAME" , "quatitso_church12");
//define("DB_NAME" , "therohic_ therohichurch");
define("DB_NAME" , "quatitso_rohichurchsystem");

$base_line = "localhost";


$count = 0;
$counter = 1;

//include '../mail/gmail.php';

?>

