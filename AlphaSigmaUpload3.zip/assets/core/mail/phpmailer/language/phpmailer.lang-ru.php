<?php


$Vsqe4yol2m0w['authenticate']         = 'Ошибка SMTP: ошибка авторизации.';
$Vsqe4yol2m0w['connect_host']         = 'Ошибка SMTP: не удается подключиться к серверу SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'Ошибка SMTP: данные не приняты.';

$Vsqe4yol2m0w['encoding']             = 'Неизвестный вид кодировки: ';
$Vsqe4yol2m0w['execute']              = 'Невозможно выполнить команду: ';
$Vsqe4yol2m0w['file_access']          = 'Нет доступа к файлу: ';
$Vsqe4yol2m0w['file_open']            = 'Файловая ошибка: не удается открыть файл: ';
$Vsqe4yol2m0w['from_failed']          = 'Неверный адрес отправителя: ';
$Vsqe4yol2m0w['instantiate']          = 'Невозможно запустить функцию mail.';

$Vsqe4yol2m0w['provide_address']      = 'Пожалуйста, введите хотя бы один адрес e-mail получателя.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' - почтовый сервер не поддерживается.';
$Vsqe4yol2m0w['recipients_failed']    = 'Ошибка SMTP: отправка по следующим адресам получателей не удалась: ';




?>
