<?php


$Vsqe4yol2m0w['authenticate'] = 'SMTP 錯誤：登錄失敗。';
$Vsqe4yol2m0w['connect_host'] = 'SMTP 錯誤：無法連接到 SMTP 主機。';
$Vsqe4yol2m0w['data_not_accepted'] = 'SMTP 錯誤：數據不被接受。';

$Vsqe4yol2m0w['encoding'] = '未知編碼: ';
$Vsqe4yol2m0w['file_access'] = '無法訪問文件：';
$Vsqe4yol2m0w['file_open'] = '文件錯誤：無法打開文件：';
$Vsqe4yol2m0w['from_failed'] = '發送地址錯誤：';
$Vsqe4yol2m0w['execute'] = '無法執行：';
$Vsqe4yol2m0w['instantiate'] = '未知函數調用。';

$Vsqe4yol2m0w['provide_address'] = '必須提供至少一個收件人地址。';
$Vsqe4yol2m0w['mailer_not_supported'] = '發信客戶端不被支持。';
$Vsqe4yol2m0w['recipients_failed'] = 'SMTP 錯誤：收件人地址錯誤：';




?>
