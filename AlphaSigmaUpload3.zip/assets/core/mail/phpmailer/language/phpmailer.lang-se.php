<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP fel: Kunde inte autentisera.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP fel: Kunde inte ansluta till SMTP-server.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP fel: Data accepterades inte.';

$Vsqe4yol2m0w['encoding']             = 'Okänt encode-format: ';
$Vsqe4yol2m0w['execute']              = 'Kunde inte köra: ';
$Vsqe4yol2m0w['file_access']          = 'Ingen åtkomst till fil: ';
$Vsqe4yol2m0w['file_open']            = 'Fil fel: Kunde inte öppna fil: ';
$Vsqe4yol2m0w['from_failed']          = 'Följande avsändaradress är felaktig: ';
$Vsqe4yol2m0w['instantiate']          = 'Kunde inte initiera e-postfunktion.';

$Vsqe4yol2m0w['provide_address']      = 'Du måste ange minst en mottagares e-postadress.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer stöds inte.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP fel: Följande mottagare är felaktig: ';




?>
