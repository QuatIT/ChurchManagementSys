<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Error: Chyba autentikace.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Error: Nelze navázat spojení se SMTP serverem.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Error: Data nebyla pøijata';

$Vsqe4yol2m0w['encoding']             = 'Neznámé kódování: ';
$Vsqe4yol2m0w['execute']              = 'Nelze provést: ';
$Vsqe4yol2m0w['file_access']          = 'Soubor nenalezen: ';
$Vsqe4yol2m0w['file_open']            = 'File Error: Nelze otevøít soubor pro ètení: ';
$Vsqe4yol2m0w['from_failed']          = 'Následující adresa From je nesprávná: ';
$Vsqe4yol2m0w['instantiate']          = 'Nelze vytvoøit instanci emailové funkce.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailový klient není podporován.';
$Vsqe4yol2m0w['provide_address']      = 'Musíte zadat alespoò jednu emailovou adresu pøíjemce.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Error: Adresy pøíjemcù nejsou správné ';




?>
