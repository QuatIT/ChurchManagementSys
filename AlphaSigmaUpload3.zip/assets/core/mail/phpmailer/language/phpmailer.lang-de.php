<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Fehler: Authentifizierung fehlgeschlagen.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Fehler: Konnte keine Verbindung zum SMTP-Host herstellen.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Fehler: Daten werden nicht akzeptiert.';
$Vsqe4yol2m0w['empty_message']        = 'E-Mail Inhalt ist leer.';
$Vsqe4yol2m0w['encoding']             = 'Unbekanntes Encoding-Format: ';
$Vsqe4yol2m0w['execute']              = 'Konnte folgenden Befehl nicht ausführen: ';
$Vsqe4yol2m0w['file_access']          = 'Zugriff auf folgende Datei fehlgeschlagen: ';
$Vsqe4yol2m0w['file_open']            = 'Datei Fehler: konnte folgende Datei nicht öffnen: ';
$Vsqe4yol2m0w['from_failed']          = 'Die folgende Absenderadresse ist nicht korrekt: ';
$Vsqe4yol2m0w['instantiate']          = 'Mail Funktion konnte nicht initialisiert werden.';
$Vsqe4yol2m0w['invalid_email']        = 'E-Mail wird nicht gesendet, die Adresse ist ungültig.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer wird nicht unterstützt.';
$Vsqe4yol2m0w['provide_address']      = 'Bitte geben Sie mindestens eine Empfänger E-Mailadresse an.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Fehler: Die folgenden Empfänger sind nicht korrekt: ';
$Vsqe4yol2m0w['signing']              = 'Fehler beim Signieren: ';
$Vsqe4yol2m0w['smtp_connect_failed']  = 'Verbindung zu SMTP Server fehlgeschlagen.';
$Vsqe4yol2m0w['smtp_error']           = 'Fehler vom SMTP Server: ';
$Vsqe4yol2m0w['variable_set']         = 'Kann Variable nicht setzen oder zurücksetzen: ';
?>
