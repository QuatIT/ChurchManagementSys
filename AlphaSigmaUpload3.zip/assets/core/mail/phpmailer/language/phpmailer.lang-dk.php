<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP fejl: Kunne ikke logge på.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP fejl: Kunne ikke tilslutte SMTP serveren.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP fejl: Data kunne ikke accepteres.';

$Vsqe4yol2m0w['encoding']             = 'Ukendt encode-format: ';
$Vsqe4yol2m0w['execute']              = 'Kunne ikke køre: ';
$Vsqe4yol2m0w['file_access']          = 'Ingen adgang til fil: ';
$Vsqe4yol2m0w['file_open']            = 'Fil fejl: Kunne ikke åbne filen: ';
$Vsqe4yol2m0w['from_failed']          = 'Følgende afsenderadresse er forkert: ';
$Vsqe4yol2m0w['instantiate']          = 'Kunne ikke initialisere email funktionen.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer understøttes ikke.';
$Vsqe4yol2m0w['provide_address']      = 'Du skal indtaste mindst en modtagers emailadresse.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP fejl: Følgende modtagere er forkerte: ';




?>
