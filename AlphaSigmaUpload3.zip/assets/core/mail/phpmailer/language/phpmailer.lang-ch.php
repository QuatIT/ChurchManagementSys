<?php


$Vsqe4yol2m0w['authenticate'] = 'SMTP 错误：身份验证失败。';
$Vsqe4yol2m0w['connect_host'] = 'SMTP 错误: 不能连接SMTP主机。';
$Vsqe4yol2m0w['data_not_accepted'] = 'SMTP 错误: 数据不可接受。';

$Vsqe4yol2m0w['encoding'] = '未知编码：';
$Vsqe4yol2m0w['execute'] = '不能执行: ';
$Vsqe4yol2m0w['file_access'] = '不能访问文件：';
$Vsqe4yol2m0w['file_open'] = '文件错误：不能打开文件：';
$Vsqe4yol2m0w['from_failed'] = '下面的发送地址邮件发送失败了： ';
$Vsqe4yol2m0w['instantiate'] = '不能实现mail方法。';

$Vsqe4yol2m0w['mailer_not_supported'] = ' 您所选择的发送邮件的方法并不支持。';
$Vsqe4yol2m0w['provide_address'] = '您必须提供至少一个 收信人的email地址。';
$Vsqe4yol2m0w['recipients_failed'] = 'SMTP 错误： 下面的 收件人失败了： ';




?>
