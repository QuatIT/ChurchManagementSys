<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Hatasý: Doðrulanamýyor.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Hatasý: SMTP hosta baðlanýlamýyor.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Hatasý: Veri kabul edilmedi.';

$Vsqe4yol2m0w['encoding']             = 'Bilinmeyen þifreleme: ';
$Vsqe4yol2m0w['execute']              = 'Çalýþtýrýlamýyor: ';
$Vsqe4yol2m0w['file_access']          = 'Dosyaya eriþilemiyor: ';
$Vsqe4yol2m0w['file_open']            = 'Dosya Hatasý: Dosya açýlamýyor: ';
$Vsqe4yol2m0w['from_failed']          = 'Baþarýsýz olan gönderici adresi: ';
$Vsqe4yol2m0w['instantiate']          = 'Örnek mail fonksiyonu yaratýlamadý.';

$Vsqe4yol2m0w['provide_address']      = 'En az bir tane mail adresi belirtmek zorundasýnýz alýcýnýn email adresi.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' mailler desteklenmemektedir.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Hatasý: alýcýlara ulaþmadý: ';




?>
