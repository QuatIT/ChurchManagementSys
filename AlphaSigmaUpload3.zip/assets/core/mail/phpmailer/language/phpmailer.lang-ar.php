<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Error: لم نستطع تأكيد الهوية.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Error: لم نستطع الاتصال بمخدم SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Error: لم يتم قبول المعلومات .';

$Vsqe4yol2m0w['encoding']             = 'ترميز غير معروف: ';
$Vsqe4yol2m0w['execute']              = 'لم أستطع تنفيذ : ';
$Vsqe4yol2m0w['file_access']          = 'لم نستطع الوصول للملف: ';
$Vsqe4yol2m0w['file_open']            = 'File Error: لم نستطع فتح الملف: ';
$Vsqe4yol2m0w['from_failed']          = 'البريد التالي لم نستطع ارسال البريد له : ';
$Vsqe4yol2m0w['instantiate']          = 'لم نستطع توفير خدمة البريد.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer غير مدعوم.';

$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Error: الأخطاء التالية ' .
                                          'فشل في الارسال لكل من : ';
$Vsqe4yol2m0w['signing']              = 'خطأ في التوقيع: ';



?>
