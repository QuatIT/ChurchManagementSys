<?php


$Vsqe4yol2m0w['authenticate']         = 'Erro de SMTP: Não foi possível autenticar.';
$Vsqe4yol2m0w['connect_host']         = 'Erro de SMTP: Não foi possível conectar com o servidor SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'Erro de SMTP: Dados não aceitos.';

$Vsqe4yol2m0w['encoding']             = 'Codificação desconhecida: ';
$Vsqe4yol2m0w['execute']              = 'Não foi possível executar: ';
$Vsqe4yol2m0w['file_access']          = 'Não foi possível acessar o arquivo: ';
$Vsqe4yol2m0w['file_open']            = 'Erro de Arquivo: Não foi possível abrir o arquivo: ';
$Vsqe4yol2m0w['from_failed']          = 'Os endereços de rementente a seguir falharam: ';
$Vsqe4yol2m0w['instantiate']          = 'Não foi possível instanciar a função mail.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer não suportado.';
$Vsqe4yol2m0w['provide_address']      = 'Você deve fornecer pelo menos um endereço de destinatário de email.';
$Vsqe4yol2m0w['recipients_failed']    = 'Erro de SMTP: Os endereços de destinatário a seguir falharam: ';




?>
