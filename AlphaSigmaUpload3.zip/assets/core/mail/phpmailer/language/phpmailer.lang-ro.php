<?php


$Vsqe4yol2m0w['authenticate']         = 'Eroare SMTP: Nu a functionat autentificarea.';
$Vsqe4yol2m0w['connect_host']         = 'Eroare SMTP: Nu m-am putut conecta la adresa SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'Eroare SMTP: Continutul mailului nu a fost acceptat.';

$Vsqe4yol2m0w['encoding']             = 'Encodare necunoscuta: ';
$Vsqe4yol2m0w['execute']              = 'Nu pot executa:  ';
$Vsqe4yol2m0w['file_access']          = 'Nu pot accesa fisierul: ';
$Vsqe4yol2m0w['file_open']            = 'Eroare de fisier: Nu pot deschide fisierul: ';
$Vsqe4yol2m0w['from_failed']          = 'Urmatoarele adrese From au dat eroare: ';
$Vsqe4yol2m0w['instantiate']          = 'Nu am putut instantia functia mail.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer nu este suportat.';
$Vsqe4yol2m0w['provide_address']      = 'Trebuie sa adaugati cel putin un recipient (adresa de mail).';
$Vsqe4yol2m0w['recipients_failed']    = 'Eroare SMTP: Urmatoarele adrese de mail au dat eroare: ';




?>
