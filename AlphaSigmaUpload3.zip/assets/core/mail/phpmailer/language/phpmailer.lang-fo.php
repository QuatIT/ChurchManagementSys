<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP feilur: Kundi ikki góðkenna.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP feilur: Kundi ikki knýta samband við SMTP vert.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP feilur: Data ikki góðkent.';

$Vsqe4yol2m0w['encoding']             = 'Ókend encoding: ';
$Vsqe4yol2m0w['execute']              = 'Kundi ikki útføra: ';
$Vsqe4yol2m0w['file_access']          = 'Kundi ikki tilganga fílu: ';
$Vsqe4yol2m0w['file_open']            = 'Fílu feilur: Kundi ikki opna fílu: ';
$Vsqe4yol2m0w['from_failed']          = 'fylgjandi Frá/From adressa miseydnaðist: ';
$Vsqe4yol2m0w['instantiate']          = 'Kuni ikki instantiera mail funktión.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' er ikki supporterað.';
$Vsqe4yol2m0w['provide_address']      = 'Tú skal uppgeva minst móttakara-emailadressu(r).';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Feilur: Fylgjandi móttakarar miseydnaðust: ';




?>
