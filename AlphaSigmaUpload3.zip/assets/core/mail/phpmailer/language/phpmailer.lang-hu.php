<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Hiba: Sikertelen autentikáció.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Hiba: Nem tudtam csatlakozni az SMTP host-hoz.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Hiba: Nem elfogadható adat.';

$Vsqe4yol2m0w['encoding']             = 'Ismeretlen kódolás: ';
$Vsqe4yol2m0w['execute']              = 'Nem tudtam végrehajtani: ';
$Vsqe4yol2m0w['file_access']          = 'Nem sikerült elérni a következõ fájlt: ';
$Vsqe4yol2m0w['file_open']            = 'Fájl Hiba: Nem sikerült megnyitni a következõ fájlt: ';
$Vsqe4yol2m0w['from_failed']          = 'Az alábbi Feladó cím hibás: ';
$Vsqe4yol2m0w['instantiate']          = 'Nem sikerült példányosítani a mail funkciót.';

$Vsqe4yol2m0w['provide_address']      = 'Meg kell adnod legalább egy címzett email címet.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' levelezõ nem támogatott.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Hiba: Az alábbi címzettek hibásak: ';




?>
