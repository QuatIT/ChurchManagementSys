<?php


$Vsqe4yol2m0w['authenticate']         = 'Error SMTP: No se pudo autentificar.';
$Vsqe4yol2m0w['connect_host']         = 'Error SMTP: No puedo conectar al servidor SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'Error SMTP: Datos no aceptados.';

$Vsqe4yol2m0w['encoding']             = 'Codificación desconocida: ';
$Vsqe4yol2m0w['execute']              = 'No puedo ejecutar: ';
$Vsqe4yol2m0w['file_access']          = 'No puedo acceder al archivo: ';
$Vsqe4yol2m0w['file_open']            = 'Error de Archivo: No puede abrir el archivo: ';
$Vsqe4yol2m0w['from_failed']          = 'La(s) siguiente(s) direcciones de remitente fallaron: ';
$Vsqe4yol2m0w['instantiate']          = 'No pude crear una instancia de la función Mail.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer no está soportado.';
$Vsqe4yol2m0w['provide_address']      = 'Debe proveer al menos una dirección de email como destinatario.';
$Vsqe4yol2m0w['recipients_failed']    = 'Error SMTP: Los siguientes destinatarios fallaron: ';
$Vsqe4yol2m0w['signing']              = 'Error al firmar: ';



?>
