<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Fout: authenticatie mislukt.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Fout: Kon niet verbinden met SMTP host.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Fout: Data niet geaccepteerd.';

$Vsqe4yol2m0w['encoding']             = 'Onbekende codering: ';
$Vsqe4yol2m0w['execute']              = 'Kon niet uitvoeren: ';
$Vsqe4yol2m0w['file_access']          = 'Kreeg geen toegang tot bestand: ';
$Vsqe4yol2m0w['file_open']            = 'Bestandsfout: Kon bestand niet openen: ';
$Vsqe4yol2m0w['from_failed']          = 'De volgende afzender adressen zijn mislukt: ';
$Vsqe4yol2m0w['instantiate']          = 'Kon mail functie niet initialiseren.';

$Vsqe4yol2m0w['provide_address']      = 'Er moet tenmiste één ontvanger emailadres opgegeven worden.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer wordt niet ondersteund.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Fout: De volgende ontvangers zijn mislukt: ';




?>
