<?php


$Vsqe4yol2m0w['authenticate'] = 'SMTP 错误：登录失败。';
$Vsqe4yol2m0w['connect_host'] = 'SMTP 错误：无法连接到 SMTP 主机。';
$Vsqe4yol2m0w['data_not_accepted'] = 'SMTP 错误：数据不被接受。';

$Vsqe4yol2m0w['encoding'] = '未知编码: ';
$Vsqe4yol2m0w['execute'] = '无法执行：';
$Vsqe4yol2m0w['file_access'] = '无法访问文件：';
$Vsqe4yol2m0w['file_open'] = '文件错误：无法打开文件：';
$Vsqe4yol2m0w['from_failed'] = '发送地址错误：';
$Vsqe4yol2m0w['instantiate'] = '未知函数调用。';

$Vsqe4yol2m0w['mailer_not_supported'] = '发信客户端不被支持。';
$Vsqe4yol2m0w['provide_address'] = '必须提供至少一个收件人地址。';
$Vsqe4yol2m0w['recipients_failed'] = 'SMTP 错误：收件人地址错误：';




?>
