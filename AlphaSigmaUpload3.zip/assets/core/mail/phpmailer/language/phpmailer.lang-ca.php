<?php


$Vsqe4yol2m0w['authenticate']         = 'Error SMTP: No s\'hapogut autenticar.';
$Vsqe4yol2m0w['connect_host']         = 'Error SMTP: No es pot connectar al servidor SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'Error SMTP: Dades no acceptades.';

$Vsqe4yol2m0w['encoding']             = 'Codificació desconeguda: ';
$Vsqe4yol2m0w['execute']              = 'No es pot executar: ';
$Vsqe4yol2m0w['file_access']          = 'No es pot accedir a l\'arxiu: ';
$Vsqe4yol2m0w['file_open']            = 'Error d\'Arxiu: No es pot obrir l\'arxiu: ';
$Vsqe4yol2m0w['from_failed']          = 'La(s) següent(s) adreces de remitent han fallat: ';
$Vsqe4yol2m0w['instantiate']          = 'No s\'ha pogut crear una instància de la funció Mail.';

$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer no està suportat';
$Vsqe4yol2m0w['provide_address']      = 'S\'ha de proveir almenys una adreça d\'email com a destinatari.';
$Vsqe4yol2m0w['recipients_failed']    = 'Error SMTP: Els següents destinataris han fallat: ';




?>
