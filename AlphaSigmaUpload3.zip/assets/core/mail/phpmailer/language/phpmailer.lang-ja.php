<?php


$Vsqe4yol2m0w['authenticate'] = 'SMTPエラー: 認証できませんでした。';
$Vsqe4yol2m0w['connect_host'] = 'SMTPエラー: SMTPホストに接続できませんでした。';
$Vsqe4yol2m0w['data_not_accepted'] = 'SMTPエラー: データが受け付けられませんでした。';

$Vsqe4yol2m0w['encoding'] = '不明なエンコーディング: ';
$Vsqe4yol2m0w['execute'] = '実行できませんでした: ';
$Vsqe4yol2m0w['file_access'] = 'ファイルにアクセスできません: ';
$Vsqe4yol2m0w['file_open'] = 'ファイルエラー: ファイルを開けません: ';
$Vsqe4yol2m0w['from_failed'] = '次のFromアドレスに間違いがあります: ';
$Vsqe4yol2m0w['instantiate'] = 'メール関数が正常に動作しませんでした。';

$Vsqe4yol2m0w['provide_address'] = '少なくとも1つメールアドレスを 指定する必要があります。';
$Vsqe4yol2m0w['mailer_not_supported'] = ' メーラーがサポートされていません。';
$Vsqe4yol2m0w['recipients_failed'] = 'SMTPエラー: 次の受信者アドレスに 間違いがあります: ';




?>
