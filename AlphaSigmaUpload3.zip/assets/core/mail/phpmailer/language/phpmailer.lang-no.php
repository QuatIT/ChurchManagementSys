<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Feil: Kunne ikke authentisere.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Feil: Kunne ikke koble til SMTP host.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Feil: Data ble ikke akseptert.';

$Vsqe4yol2m0w['encoding']             = 'Ukjent encoding: ';
$Vsqe4yol2m0w['execute']              = 'Kunne ikke utføre: ';
$Vsqe4yol2m0w['file_access']          = 'Kunne ikke få tilgang til filen: ';
$Vsqe4yol2m0w['file_open']            = 'Fil feil: Kunne ikke åpne filen: ';
$Vsqe4yol2m0w['from_failed']          = 'Følgende Fra feilet: ';
$Vsqe4yol2m0w['instantiate']          = 'Kunne ikke instantiate mail funksjonen.';

$Vsqe4yol2m0w['provide_address']      = 'Du må ha med minst en mottager adresse.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' mailer er ikke supportert.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Feil: Følgende mottagere feilet: ';




?>
