<?php


$Vsqe4yol2m0w['authenticate'] = 'Błąd SMTP: Nie można przeprowadzić autentykacji.';
$Vsqe4yol2m0w['connect_host'] = 'Błąd SMTP: Nie można połączyć się z wybranym hostem.';
$Vsqe4yol2m0w['data_not_accepted'] = 'Błąd SMTP: Dane nie zostały przyjęte.';

$Vsqe4yol2m0w['encoding'] = 'Nieznany sposób kodowania znaków: ';
$Vsqe4yol2m0w['execute'] = 'Nie można uruchomić: ';
$Vsqe4yol2m0w['file_access'] = 'Brak dostępu do pliku: ';
$Vsqe4yol2m0w['file_open'] = 'Nie można otworzyć pliku: ';
$Vsqe4yol2m0w['from_failed'] = 'Następujący adres Nadawcy jest jest nieprawidłowy: ';
$Vsqe4yol2m0w['instantiate'] = 'Nie można wywołać funkcji mail(). Sprawdź konfigurację serwera.';

$Vsqe4yol2m0w['provide_address'] = 'Należy podać prawidłowy adres email Odbiorcy.';
$Vsqe4yol2m0w['mailer_not_supported'] = 'Wybrana metoda wysyłki wiadomości nie jest obsługiwana.';
$Vsqe4yol2m0w['recipients_failed'] = 'Błąd SMTP: Następujący odbiorcy są nieprawidłowi: ';




?>
