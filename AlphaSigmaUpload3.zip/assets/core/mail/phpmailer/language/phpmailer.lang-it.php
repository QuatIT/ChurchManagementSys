<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Error: Impossibile autenticarsi.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Error: Impossibile connettersi all\'host SMTP.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Error: Data non accettati dal server.';

$Vsqe4yol2m0w['encoding']             = 'Encoding set dei caratteri sconosciuto: ';
$Vsqe4yol2m0w['execute']              = 'Impossibile eseguire l\'operazione: ';
$Vsqe4yol2m0w['file_access']          = 'Impossibile accedere al file: ';
$Vsqe4yol2m0w['file_open']            = 'File Error: Impossibile aprire il file: ';
$Vsqe4yol2m0w['from_failed']          = 'I seguenti indirizzi mittenti hanno generato errore: ';
$Vsqe4yol2m0w['instantiate']          = 'Impossibile istanziare la funzione mail';

$Vsqe4yol2m0w['provide_address']      = 'Deve essere fornito almeno un indirizzo ricevente';
$Vsqe4yol2m0w['mailer_not_supported'] = 'Mailer non supportato';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Error: I seguenti indirizzi destinatari hanno generato errore: ';




?>
