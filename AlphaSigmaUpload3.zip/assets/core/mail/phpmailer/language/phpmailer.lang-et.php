<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP Viga: Autoriseerimise viga.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP Viga: Ei õnnestunud luua ühendust SMTP serveriga.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP Viga: Vigased andmed.';

$Vsqe4yol2m0w['encoding']             = 'Tundmatu Unknown kodeering: ';
$Vsqe4yol2m0w['execute']              = 'Tegevus ebaõnnestus: ';
$Vsqe4yol2m0w['file_access']          = 'Pole piisavalt õiguseid järgneva faili avamiseks: ';
$Vsqe4yol2m0w['file_open']            = 'Faili Viga: Faili avamine ebaõnnestus: ';
$Vsqe4yol2m0w['from_failed']          = 'Järgnev saatja e-posti aadress on vigane: ';
$Vsqe4yol2m0w['instantiate']          = 'mail funktiooni käivitamine ebaõnnestus.';

$Vsqe4yol2m0w['provide_address']      = 'Te peate määrama vähemalt ühe saaja e-posti aadressi.';
$Vsqe4yol2m0w['mailer_not_supported'] = ' maileri tugi puudub.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP Viga: Järgnevate saajate e-posti aadressid on vigased: ';




?>
