<?php


$Vsqe4yol2m0w['authenticate']         = 'SMTP-virhe: käyttäjätunnistus epäonnistui.';
$Vsqe4yol2m0w['connect_host']         = 'SMTP-virhe: yhteys palvelimeen ei onnistu.';
$Vsqe4yol2m0w['data_not_accepted']    = 'SMTP-virhe: data on virheellinen.';

$Vsqe4yol2m0w['encoding']             = 'Tuntematon koodaustyyppi: ';
$Vsqe4yol2m0w['execute']              = 'Suoritus epäonnistui: ';
$Vsqe4yol2m0w['file_access']          = 'Seuraavaan tiedostoon ei ole oikeuksia: ';
$Vsqe4yol2m0w['file_open']            = 'Tiedostovirhe: Ei voida avata tiedostoa: ';
$Vsqe4yol2m0w['from_failed']          = 'Seuraava lähettäjän osoite on virheellinen: ';
$Vsqe4yol2m0w['instantiate']          = 'mail-funktion luonti epäonnistui.';

$Vsqe4yol2m0w['mailer_not_supported'] = 'postivälitintyyppiä ei tueta.';
$Vsqe4yol2m0w['provide_address']      = 'Aseta vähintään yksi vastaanottajan sähk&ouml;postiosoite.';
$Vsqe4yol2m0w['recipients_failed']    = 'SMTP-virhe: seuraava vastaanottaja osoite on virheellinen.';
$Vsqe4yol2m0w['encoding']             = 'Tuntematon koodaustyyppi: ';




?>
