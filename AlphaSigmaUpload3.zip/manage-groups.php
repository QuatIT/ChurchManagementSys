<?php
$dropactive = "ministry";
$active = "gministry";
include 'layout/headside.php';


if(isset($_POST['submit'])){
    $ministryID = htmlspecialchars(trim($_POST['ministryID']));
    $ministryName = htmlspecialchars(trim($_POST['ministryName']));
    
    $saveMinistry = insert("INSERT INTO g_ministry_tb(branch_id,g_id,g_name) VALUES('$churchID','$ministryID','$ministryName')");
    
    if($saveMinistry){
        $s = "success";
        echo "<script>window.location.href='manage-group?m=$s</script>";
    }else{
        echo "<script type='text/javascript'>toastr.error('PLEASE TRY AGAIN LATER','FAILED',{timeOut: 7000})</script>";
    }
}


if(@$_GET['m']);
if(@$_GET['m'] == 'success'){
    echo "<script type='text/javascript'>toastr.success('MINISTRY CREATED SUCCESSFULL','SUCCESS',{timeOut: 7000})</script>";
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">OTHER GROUPS </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Ministry</a></li>
              <li class="breadcrumb-item active">Other Groups</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid"> 
        <div class="row">
            <div class="col-md-5">
                <div class="card card-default">
                  <div class="card-header">
                    <h3 class="card-title">CREATE GROUP</h3>
                    <div class="card-tools">
                    </div>
                  </div>
                    <form class="form" action="" method="post" enctype="multipart/form-data">

                  <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                              <label>GROUP ID <i class="text-danger">*</i></label>
                                <input type="text" class="form-control" name="ministryID" value="<?php echo "GRP-".rand(10,50).rand(100,999);?>" placeholder="Ministry ID" required readonly />
                            </div>
                            <div class="form-group">
                              <label>GROUP NAME <i class="text-danger">*</i></label>
                                  <input type="text" class="form-control" name="ministryName" placeholder="Group Name" required />
                            </div>
                            <div class="form-group">
<!--                                <label style="color:white;">.</label>-->
                                <input type="submit" name="submit" onclick="return confirm('CREATE GROUP ?');" value="CREATE GROUP" class="btn btn-primary btn-block btn-md" />  
                            </div>
                        </div>
                        
                    </div>
                  </div>
                    </form>
<!--                  <div class="card-footer"></div>-->
                </div>
            </div>  
            
            
            <div class="col-md-7">
                        <div class="card">
              <div class="card-header">
                <h3 class="card-title">CREATED GROUPS LIST</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>GROUP ID</th>
                    <th>GROUP NAME</th>
                  </tr>
                  </thead>
                  <tbody>
                <?php
                 $getministry = select("SELECT g_id, g_name FROM g_ministry_tb WHERE branch_id='$churchID'");
                      if($getministry){
                    foreach($getministry as $mingotten){
                    
                ?>
                  <tr>
                    <td> <?php echo $mingotten['g_id'];?> </td>
                    <td> <?php echo $mingotten['g_name'];?> </td>
<!--                    <td> X </td>-->
                  </tr>
                      <?php }}?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            </div>  
        </div>
      </div>
    </section>
  </div>

<?php
include 'layout/footer.php';    
?>